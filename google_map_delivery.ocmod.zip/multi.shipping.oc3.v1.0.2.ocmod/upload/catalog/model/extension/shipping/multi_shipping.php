<?php
class ModelExtensionShippingMultiShipping extends Model {
	public function getQuote($address) {
		$this->load->language('extension/shipping/multi_shipping');
	
		$shipping_methods = $this->config->get('shipping_multi_shipping_method');
		$quote_data = array();
		$method_data = array();
	
		$origin = $this->config->get('shipping_multi_shipping_store_address'); // Adresa magazinului
		
		if (!empty($shipping_methods)) {
			foreach ($shipping_methods as $method) {
				if (!$method['status']) {
					continue; // Ignorăm metodele care nu sunt active
				}
	
				$price_per_km = isset($method['price']) ? (float)$method['price'] : 0;
				$price_per_kg = isset($method['price_per_kg']) ? (float)$method['price_per_kg'] : 0;
				$price_per_m3 = isset($method['price_per_m3']) ? (float)$method['price_per_m3'] : 0;
				$free_limit = isset($method['free_limit']) ? (float)$method['free_limit'] : null;
				$fixed_fee = isset($method['fixed_fee']) ? (float)$method['fixed_fee'] : null;
	
				// Preluăm datele coșului
				$cart_total = $this->cart->getTotal();  // Totalul sumei produselor din coș
				$cart_weight = $this->cart->getWeight();  // Greutatea totală a coșului
				$cart_volume = $this->getCartVolume();  // Volumul total al coșului
				$cost = 0;
	
				// Construim adresa completă a destinatarului
				$destination = $address['address_1'] . ', ' . $address['city'] . ', ' . $address['zone'] . ', ' . $address['country'];
	
				// Calculăm distanța folosind Google Maps API
				$distance = $this->getDistance($origin, $destination, $this->config->get('shipping_multi_shipping_google_api_key'));
	
				// Afișare pentru debugging
				echo "Total cos: " . $cart_total . "<br/>";
				echo "Limita pentru livrare gratuită: " . $free_limit . "<br/>";
				echo "Bifa livrare gratuită activată? " . (isset($method['enable_free_limit']) && $method['enable_free_limit'] ? 'DA' : 'NU') . "<br/>";
	
				// Aplicăm logica pentru livrare gratuită
				if (isset($method['enable_free_limit']) && $method['enable_free_limit'] && $cart_total >= $free_limit) {
					$cost = 0; // Livrare gratuită
				} else {
					// Calculăm costurile în funcție de bife
					if (isset($method['enable_price']) && $distance !== false) {
						$cost += $price_per_km * $distance;
					}
	
					if (isset($method['enable_price_per_kg'])) {
						$cost += $price_per_kg * $cart_weight;
					}
	
					if (isset($method['enable_price_per_m3'])) {
						$cost += $price_per_m3 * $cart_volume;
					}
	
					// Aplicăm taxa fixă dacă nu există alt cost
					if ($cost == 0 && $fixed_fee !== null) {
						$cost = $fixed_fee;
					}
				}
	
				// În cazul în care niciun criteriu nu este activat sau nu are valori valide, costul va rămâne 0
				if ($cost == 0 && $free_limit === null) {
					$cost = 5.00; // Cost implicit dacă nu există alte criterii de calcul și nu avem o limită
				}
	
				// Adăugăm metoda de livrare în array-ul de răspuns
				$quote_data[$method['name'][$this->config->get('config_language_id')]] = array(
					'code'         => 'multi_shipping.' . $method['name'][$this->config->get('config_language_id')],
					'title'        => $method['name'][$this->config->get('config_language_id')] . ' (' . $method['comment'][$this->config->get('config_language_id')] . ')',
					'cost'         => $cost,
					'tax_class_id' => 0,
					'text'         => $this->currency->format($cost, $this->session->data['currency'])
				);
			}
		}
	
		if (!empty($quote_data)) {
			$method_data = array(
				'code'       => 'multi_shipping',
				'title'      => $this->language->get('text_title'),
				'quote'      => $quote_data,
				'sort_order' => $this->config->get('shipping_multi_shipping_sort_order'),
				'error'      => false
			);
		}
	
		return $method_data;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

    // Funcția care calculează distanța dintre două puncte folosind Google Maps Distance Matrix API
    private function getDistance($origin, $destination, $api_key) {
        // Crearea URL-ului pentru API-ul Google Distance Matrix
        $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?origins=' . urlencode($origin) . '&destinations=' . urlencode($destination) . '&key=' . $api_key;
        
        // Trimite cererea și decodează răspunsul JSON
        $response = file_get_contents($url);
        $data = json_decode($response, true);
		echo '<pre>';
        print_r($data);
        echo '</pre>';
        // Verificăm dacă distanța a fost returnată corect
        if (!empty($data['rows'][0]['elements'][0]['distance'])) {
            // Returnăm distanța în kilometri
            return $data['rows'][0]['elements'][0]['distance']['value'] / 1000;
        }
        
        // Dacă nu s-a putut calcula distanța, returnăm false
        return false;
    }

    // Funcție pentru a obține volumul total al coșului (exemplu - trebuie definită corect)
    private function getCartVolume() {
        $cart_products = $this->cart->getProducts();
        $total_volume = 0;

        foreach ($cart_products as $product) {
            // Calculăm volumul produsului: Lățime * Înălțime * Lungime
            $product_volume = $product['width'] * $product['height'] * $product['length'];
            $total_volume += $product_volume;
        }

        return $total_volume; // Returnăm volumul total al coșului
    }
}
