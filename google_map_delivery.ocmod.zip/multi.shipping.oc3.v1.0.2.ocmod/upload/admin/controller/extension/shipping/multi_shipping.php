<?php
class ControllerExtensionShippingMultiShipping extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/shipping/multi_shipping');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('setting/store');
		$this->load->model('localisation/tax_class');
		$this->load->model('localisation/language');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$shipping_methods = $this->request->post['shipping_multi_shipping_method'];
			
			foreach ($shipping_methods as $key => $method) {
				// Bifele sunt salvate ca 1 dacă sunt selectate, altfel setăm la 0
				$shipping_methods[$key]['enable_price'] = isset($method['enable_price']) ? 1 : 0;
				$shipping_methods[$key]['enable_price_per_kg'] = isset($method['enable_price_per_kg']) ? 1 : 0;
				$shipping_methods[$key]['enable_price_per_m3'] = isset($method['enable_price_per_m3']) ? 1 : 0;
				$shipping_methods[$key]['enable_free_limit'] = isset($method['enable_free_limit']) ? 1 : 0; // Bifa pentru limita de livrare gratuită
			}
			
			// Salvăm setările
			$this->model_setting_setting->editSetting('shipping_multi_shipping', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/shipping/multi_shipping', 'user_token=' . $this->session->data['user_token'] . '&type=shipping', true));
		}

		// Preluăm taxele, limbile și magazinele
		$data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();
		$data['languages'] = $this->model_localisation_language->getLanguages();
		$data['stores'] = array();

		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default')
		);

		$stores = $this->model_setting_store->getStores();

		foreach ($stores as $store) {
			$data['stores'][] = array(
				'store_id' => $store['store_id'],
				'name'     => $store['name']
			);
		}

		// Preluăm cheia API Google
		if (isset($this->request->post['shipping_multi_shipping_google_api_key'])) {
			$data['shipping_multi_shipping_google_api_key'] = $this->request->post['shipping_multi_shipping_google_api_key'];
		} else if ($this->config->has('shipping_multi_shipping_google_api_key')) {
			$data['shipping_multi_shipping_google_api_key'] = $this->config->get('shipping_multi_shipping_google_api_key');
		} else {
			$data['shipping_multi_shipping_google_api_key'] = '';
		}

		// Preluăm adresa magazinului
		if (isset($this->request->post['shipping_multi_shipping_store_address'])) {
			$data['shipping_multi_shipping_store_address'] = $this->request->post['shipping_multi_shipping_store_address'];
		} else if ($this->config->get('shipping_multi_shipping_store_address')) {
			$data['shipping_multi_shipping_store_address'] = $this->config->get('shipping_multi_shipping_store_address');
		} else {
			$data['shipping_multi_shipping_store_address'] = '';
		}

		// Preluăm metodele de livrare și valorile pentru bife și taxe
		$data['shipping_multi_shipping_method'] = array();
		if (isset($this->request->post['shipping_multi_shipping_method'])) {
			$data['shipping_multi_shipping_method'] = $this->request->post['shipping_multi_shipping_method'];
		} else if($this->config->has('shipping_multi_shipping_method')){
			$data['shipping_multi_shipping_method'] = $this->config->get('shipping_multi_shipping_method');
		}

		foreach ($data['shipping_multi_shipping_method'] as $key => $method) {
			$data['shipping_multi_shipping_method'][$key]['price'] = isset($method['price']) ? $method['price'] : 0;
			$data['shipping_multi_shipping_method'][$key]['price_per_kg'] = isset($method['price_per_kg']) ? $method['price_per_kg'] : 0;
			$data['shipping_multi_shipping_method'][$key]['price_per_m3'] = isset($method['price_per_m3']) ? $method['price_per_m3'] : 0;
			$data['shipping_multi_shipping_method'][$key]['free_limit'] = isset($method['free_limit']) ? $method['free_limit'] : 0;
			$data['shipping_multi_shipping_method'][$key]['fixed_fee'] = isset($method['fixed_fee']) ? $method['fixed_fee'] : 0; // Taxa fixă

			// Bifele
			$data['shipping_multi_shipping_method'][$key]['enable_price'] = isset($method['enable_price']) ? $method['enable_price'] : 0;
			$data['shipping_multi_shipping_method'][$key]['enable_price_per_kg'] = isset($method['enable_price_per_kg']) ? $method['enable_price_per_kg'] : 0;
			$data['shipping_multi_shipping_method'][$key]['enable_price_per_m3'] = isset($method['enable_price_per_m3']) ? $method['enable_price_per_m3'] : 0;
			$data['shipping_multi_shipping_method'][$key]['enable_free_limit'] = isset($method['enable_free_limit']) ? $method['enable_free_limit'] : 0; // Bifa pentru limită
		}

		// Status general și ordinea de sortare
		$data['shipping_multi_shipping_status'] = isset($this->request->post['shipping_multi_shipping_status']) ? $this->request->post['shipping_multi_shipping_status'] : $this->config->get('shipping_multi_shipping_status');
		$data['shipping_multi_shipping_sort_order'] = isset($this->request->post['shipping_multi_shipping_sort_order']) ? $this->request->post['shipping_multi_shipping_sort_order'] : $this->config->get('shipping_multi_shipping_sort_order');

		// Gestionarea erorilor
		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';

		// Setăm token-ul utilizatorului
		$data['user_token'] = $this->session->data['user_token'];

		// Încarcă părțile paginii (header, coloana stângă, footer)
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		// Randăm template-ul cu datele colectate
		$this->response->setOutput($this->load->view('extension/shipping/multi_shipping', $data));
	}

	// Funcția de validare
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/shipping/multi_shipping')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (isset($this->request->post['shipping_multi_shipping_method'])) {
			$methods = $this->request->post['shipping_multi_shipping_method'];
			
			foreach ($methods as $key => $method) {
				foreach ($method['name'] as $lkey => $language) {
					if (empty($language) || trim($language) == "") {
						$this->error['method'][$key]['name'][$lkey] = $this->language->get('error_name');
					}
				}

				if (!isset($method['status']) || $method['status'] === '') {
					$this->error['method'][$key]['status'] = $this->language->get('error_status');
				}
			}
		}

		return !$this->error;
	}
}
